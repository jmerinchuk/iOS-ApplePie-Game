/**********************************************************************************
 * Program: Apple Pie
 * Programmer: Jayce Merinchuk
 * Date: August 1, 2019
 * Description: Word guessing Game that allows the user to press the letter buttons
 * to guess the word on screen.  They get X number of guesses where X is the
 * number of apples left on the tree.
 * a new round is started when all the apples are gone or the word was guessed.
 *********************************************************************************/

// Imports
import Foundation

/**********************************************************************************
 * Method: Game struct
 * Description: Holds the state of the game, counts incorrect moves, and players
 * guessed letters
 *********************************************************************************/
struct Game {
    var word: String
    var incorrectMovesRemaining: Int
    var guessedLetters: [Character]
    
    var formattedWord: String {
        var guessedWord = ""
        for letter in word {
            if guessedLetters.contains(letter) {
                guessedWord += "\(letter)"
            } else {
                guessedWord += "_"
            }
        }
        return guessedWord
    }
    
    mutating func playerGuessed(letter: Character) {
        guessedLetters.append(letter)
        
        if !word.contains(letter) {
            incorrectMovesRemaining -= 1
        }
    }
}
