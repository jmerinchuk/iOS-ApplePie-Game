/**********************************************************************************
 * Program: Apple Pie
 * Programmer: Jayce Merinchuk
 * Date: August 1, 2019
 * Description: Word guessing Game that allows the user to press the letter buttons
 * to guess the word on screen.  They get X number of guesses where X is the
 * number of apples left on the tree.
 * a new round is started when all the apples are gone or the word was guessed.
 *********************************************************************************/

// Imports
import UIKit

/**********************************************************************************
 * Class: View Controller
 * Description: Single View for the Application
 *********************************************************************************/
class ViewController: UIViewController {
    
    // Outlets
    @IBOutlet weak var treeImageView: UIImageView!
    @IBOutlet weak var correctWordLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet var letterButtons: [UIButton]!
    
    // Class Variables
    var listOfWords = ["cupcake", "melon", "cabin", "fishing", "basketball", "homework", "videogame", "fashionable", "tastetest", "velocity"]
    let incorrectMovesAllowed = 7
    var totalWins = 0 {
        didSet {
            newRound()
        }
    }
    var totalLosses = 0 {
        didSet {
            newRound()
        }
    }
    var currentGame: Game!
    
    /******************************************************************************
     * Method: viewDidLoad()
     * Description: Initial function loaded on app start
     *****************************************************************************/
    override func viewDidLoad() {
        super.viewDidLoad()
        newRound()
    }
    
    /******************************************************************************
     * Method: newRound()
     * Description: Chooses new word, resets buttons, resets moves.
     *****************************************************************************/
    func newRound() {
        if !listOfWords.isEmpty {
            let newWord = listOfWords.randomElement()
            currentGame = Game(word: newWord!, incorrectMovesRemaining: incorrectMovesAllowed, guessedLetters: [])
            updateUI()
        }
        enableLetterButtons(true)
    }
    
    /******************************************************************************
     * Method: updateUI()
     * Description: Updates the current Game word and screen for changes.
     *****************************************************************************/
    func updateUI() {
        var letters = [String]()
        
        for letter in currentGame.formattedWord {
            letters.append(String(letter))
        }
        
        let wordWithSpacing = letters.joined(separator: " ")
        correctWordLabel.text = wordWithSpacing
        scoreLabel.text = "Wins: \(totalWins), Losses: \(totalLosses)"
        treeImageView.image = UIImage(named: "Tree \(currentGame.incorrectMovesRemaining)")
    }
    
    /******************************************************************************
     * Method: buttonPressed
     * Description: Disable button when pressed, get button title, share to Game.
     *****************************************************************************/
    @IBAction func buttonPressed(_ sender: UIButton) {
        sender.isEnabled = false
        let letterString = sender.title(for: .normal)!
        let letter = Character(letterString.lowercased())
        currentGame.playerGuessed(letter: letter)
        updateGameState()
    }
    
    /******************************************************************************
     * Method: updateGameState()
     * Description:updates number of moves remaining and wins/losses
     *****************************************************************************/
    func updateGameState() {
        if (currentGame.incorrectMovesRemaining == 0) {
            totalLosses += 1
        } else if (currentGame.word == currentGame.formattedWord) {
            totalWins += 1
        } else {
            updateUI()
        }
    }
    
    /******************************************************************************
     * Method: enableLetterButtons()
     * Description:re-enables all buttons when the game resets.
     *****************************************************************************/
    func enableLetterButtons(_ enable: Bool) {
        for button in letterButtons {
            button.isEnabled = enable
        }
    }
}
